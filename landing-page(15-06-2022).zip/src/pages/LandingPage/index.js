import LandingPage from './LandingPage';

export default LandingPage;
