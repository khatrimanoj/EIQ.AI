import StatisticsItem from './StatisticsItem';

export default StatisticsItem;
