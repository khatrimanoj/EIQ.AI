import ProductTicker from "./ProductTicker";

export default ProductTicker;
