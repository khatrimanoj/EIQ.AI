import StatisticsBar from './StatisticsBar';

export default StatisticsBar;
